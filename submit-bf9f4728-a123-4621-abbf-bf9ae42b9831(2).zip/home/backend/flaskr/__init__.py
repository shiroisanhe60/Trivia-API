import os
from flask import Flask, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random

from models import setup_db, Question, Category

QUESTIONS_PER_PAGE = 10

def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__)
    setup_db(app)

def setup_CORS(app)
    cors = CORS(app, resources={r"/api/*": {"origin": "*"}})

  

    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,true')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PATCH,POST,DELETE,OPTIONS')
        return response
    
    @app.route('/categories')
    @cross_origin()
    def get_categories():
        return 'GETTING ALL CATEGORIES'


    @app.route('/questions', methods=['GET'])
    def get_question():
    GET /items?limit=10
        return questions
  
  

    @app.route('/questions', methods=['DELETE'])
    @Path("{id}")
    def delete_question():
        return response


    @app.rout('/questions', methods=['POST'])
    def create_question():
        return question



    @app.rout('/questions', methods='GET', callback='getAllPostsfromCategory')
    def get_question():
        return question


 
   
    @app.route('/categories/<int:category_id>/questions')
    def get_questions_by_categories():
        return question

   
    @app.route ('/quizzes', methods=['POST'])
    def get_quiz_question():
    category = Category.query.get(category_id)
    question = Question.query.all()
        return question

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
        "success": False,
        "error": 404,
        "message": "Resource Not found"
    }), 404


    @app.errorhandler(422)
    def process_failed(error):
        return jsonify({
        "success": False,
        "error": 422,
        "message": "Process failed"
    }), 422

    return app
